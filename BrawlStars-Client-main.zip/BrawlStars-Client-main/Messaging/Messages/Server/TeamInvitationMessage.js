var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    decode(messaging) {
        console.log(this.ByteStream.readVInt());
        var highid = this.ByteStream.readInt();
        var lowid = this.ByteStream.readInt()
        console.log(highid);
        console.log(lowid);
        messaging.TeamInvitationResponseMessage(highid, lowid);
    }
    process(messaging) {
        // messaging.TeamChatMessage("Hi! I am shelly bot made by renogang1!");
        // messaging.TeamChatMessage("Hi! I am shelly bot made by renogang1!");
        // messaging.TeamChatMessage("Hi! I am shelly bot made by renogang1!");
        // messaging.TeamChatMessage("Hi! I am shelly bot made by renogang1!");
        // messaging.TeamChatMessage("Hi! I am shelly bot made by renogang1!");
        // messaging.TeamChatMessage("Hi! I am shelly bot made by renogang1!");
        // messaging.TeamChatMessage("Hi! I am shelly bot made by renogang1!");
    }
}

module.exports.getMessageType = () =>  24589;