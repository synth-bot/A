var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    decode() {
        // console.log("Unk int" + this.ByteStream.readInt());
        // console.log("Unk int" + this.ByteStream.readInt());
        // // console.log(this.ByteStream.readInt());
        // // console.log(this.ByteStream.readInt());
    }
    process(messaging) {
        messaging.TeamSetMemberReadyMessage();
        messaging.TeamPremadeChatMessage();
    }
}

module.exports.getMessageType = () => 24131;