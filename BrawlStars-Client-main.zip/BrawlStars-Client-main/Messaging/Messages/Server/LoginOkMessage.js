var ByteStream = require("../../../DataStream/ByteStream");
const fs = require('fs');
module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
	
    decode() {
		function getHashtagfromId(Id) {
			var TagChar = ["0", "2", "8", "9", "P", "Y", "L", "Q", "G", "R", "J", "C", "U", "V"];
      		var Tag = []; 
			while (Id > BigInt(0)) { 
				var CharIndex = Math.floor(parseInt(Id % BigInt(TagChar.length))); 
				Tag.push(TagChar[CharIndex]); 
				Id -= BigInt(CharIndex); 
				Id /= BigInt(TagChar.length);
			  }
			return ("" + Tag.reverse());
		}
		console.log("Logged as:");
		var highid = this.ByteStream.readInt()
		var lowid = this.ByteStream.readInt()
        console.log("HIGHID:" + highid);
		console.log("LOWID:" + lowid);
		this.ByteStream.readInt();
		this.ByteStream.readInt();
		var passToken = this.ByteStream.readString()
		console.log("PassToken:" + passToken);
		var tag = "#" + getHashtagfromId(BigInt(highid) + (BigInt(lowid) << BigInt(8))).replaceAll(",", "")
		console.log("Tag:" + tag);
		fs.writeFileSync("./Bots/" + tag, highid + "::" + lowid + "::" + passToken + "::" + tag,
		err => {
			if (err) {
			  Debugger.warning("Failed to write botfile with tag " + tag);
			}});
		// const sensor = spawn('python', ['Id2Tag.py ' + highid + " " + lowid]);
		// sensor.stdout.on('data', function(data) {
		// 	var tag = data;
		// 	console.log("Tag:" + tag);
		// });
    }
	process(messaging, socket) {
		// messaging.sendGetPlayerProfileMessage(25,7735040, true);
		messaging.sendChangeAvatarNameMessage("мать иллки");
		console.log("da");
		messaging.sendAddFriendMessage(29, 10438151);

		// messaging.sendCorruptedMessage();
		setTimeout(() => {socket.destroy()}, 3000); // prints 
		// messaging.sendPepperLogin();
		// messaging.TeamJoinMessage();
		// messaging.TeamChatMessage();
	}
}
module.exports.getMessageType = () => 20104;