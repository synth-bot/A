var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    encode() { 
        this.ByteStream.writeVInt(11); //type?
		this.ByteStream.writeVInt(34563); //room id
        this.ByteStream.writeVInt(11); //unk
        this.ByteStream.writeDataReference(1,0); //unk
    }
}