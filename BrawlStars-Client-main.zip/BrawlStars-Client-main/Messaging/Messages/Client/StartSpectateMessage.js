var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    encode(high, low, tv) {
        // this.ByteStream.writeInt(101393409);
        // this.ByteStream.writeBoolean(false);
        // this.ByteStream.writeVInt(0);

        // this.ByteStream.writeBoolean(true);

       // this.ByteStream.writeString("bonuska");
		//this.ByteStream.writeString("bonuska");
		//this.ByteStream.writeInt(25); povannoye vimya
		//this.ByteStream.writeInt(7735040);
		this.ByteStream.writeInt(parseInt(high));
		this.ByteStream.writeInt(parseInt(low));
		this.ByteStream.writeBoolean(tv);
    }
}