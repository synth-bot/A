var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    encode(high, low) { 
        this.ByteStream.writeInt(parseInt(high));
		this.ByteStream.writeInt(parseInt(low));
		this.ByteStream.writeInt(3); // 0 = from id (without any shit), 1 = from club, 2 = from team, 3 = from battle (second wInt = number of battles < 100), 4 = from battle (number of battles = 0), 5 >= invisible :upside_down:
		this.ByteStream.writeInt(69); // :upside_down:
       
    }
}