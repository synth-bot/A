# BrawlStars-Client
client for brawl stars v46 prod server

it's been a while since someone shared something like this 🙃

# NOTE
This content is not affiliated with, endorsed,sponsored, or specifically approved by supercell and supercell is not responsible for it.

In addition, you are the only person responsible for your actions when using it.

## usage 
install required module(s):
```
npm install 
```
run the program:
```
node Program.js game.brawlstarsgame.com 9339
```
if you want to save decrypted server packets, run the program with:
```
node Program.js game.brawlstarsgame.com 9339 dump
```

# credits
this project was made by S.B#0056 and risporce#6552

## give a 🌟 because why not :p

# [join my discord server](https://discord.gg/b2ejYcJjqA)
